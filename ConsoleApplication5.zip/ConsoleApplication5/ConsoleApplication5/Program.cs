﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Password : ");
            char[] password = Console.ReadLine().ToCharArray();
            SecureString convertedPassword = ConvertToSecureString(password);
            char[] passwordChar = ConvertToCharacter(convertedPassword);
        }

        private static SecureString ConvertToSecureString(char[] password)
        {
            if (password == null)
                throw new ArgumentNullException("password");

            var securePassword = new SecureString();

            Array.ForEach(password, securePassword.AppendChar);

            securePassword.MakeReadOnly();
            return securePassword;
        }

        private static char[] ConvertToCharacter(SecureString convertedPassword)
        {
            char[] bytes;
            var ptr = IntPtr.Zero;

            try
            {               
                ptr = Marshal.SecureStringToBSTR(convertedPassword);
                bytes = new char[convertedPassword.Length];
                Marshal.Copy(ptr, bytes, 0, convertedPassword.Length);
            }
            finally
            {
                if (ptr != IntPtr.Zero)
                {
                    Marshal.ZeroFreeBSTR(ptr);
                }
            }

            return bytes;
        }
    }
}
